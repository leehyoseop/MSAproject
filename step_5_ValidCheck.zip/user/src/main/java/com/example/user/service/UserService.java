package com.example.user.service;

import com.example.user.dto.UserDto;
import com.example.user.mapper.UserMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class UserService {

    private final UserMapper userMapper;

    //전체 조회
    public List<UserDto> getUserList() {
        return userMapper.findAll();
    }
    //상세 조회
    public UserDto getUser(String id) {
        return userMapper.findById(id);
    }
    //등록
    public int addUser(UserDto userDto) {
        int count = userMapper.save(userDto);
        return count;
    }
    //수정
    public int modUser(UserDto userDto) {
        int count = userMapper.update(userDto);
        return count;
    }
    //삭제
    public int removeUser(String id) {
        int count = userMapper.deleteById(id);
        return count;
    }
}
