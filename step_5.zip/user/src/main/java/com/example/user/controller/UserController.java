package com.example.user.controller;

import com.example.user.dto.UserDto;
import com.example.user.service.UserService;
import io.swagger.v3.oas.annotations.Operation;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/user")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;

    //전체 조회
    @GetMapping("")
    @Operation(summary = "사용자 전체조회")
    public ResponseEntity<List<UserDto>> getListUser() {
        return ResponseEntity.status(HttpStatus.OK).body(userService.getUserList());
    }

    //상세 조회
    @GetMapping("{id}")
    @Operation(summary = "사용자 상세조회")
    public ResponseEntity<UserDto> getOneUser(@PathVariable("id") String id) {
        return ResponseEntity.status(HttpStatus.OK).body(userService.getUser(id));
    }
    //등록
    @PostMapping("")
    @Operation(summary = "사용자 등록")
    public ResponseEntity<Integer> addUser(@RequestBody UserDto userDto) {
        return ResponseEntity.status(HttpStatus.OK).body(userService.addUser(userDto));
    }
    //수정
    @PutMapping("{id}")
    @Operation(summary = "사용자 수정")
    public ResponseEntity<Integer> modUser(@PathVariable("id") String id, @RequestBody UserDto userDto) {
        userDto.setUserid(id);
        return ResponseEntity.ok(userService.modUser(userDto));
    }
    //삭제
    @DeleteMapping("{id}")
    @Operation(summary = "사용자 삭제")
    public ResponseEntity<Integer> removeUser(@PathVariable("id") String id) {
        return ResponseEntity.ok(userService.removeUser(id));
    }
}
