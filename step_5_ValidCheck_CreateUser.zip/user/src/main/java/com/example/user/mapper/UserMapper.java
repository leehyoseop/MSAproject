package com.example.user.mapper;

import com.example.user.dto.UserDto;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface UserMapper {
    //전체 조회
    List<UserDto> findAll();
    //상세 조회
    UserDto findById(String id);
    //등록
    int save(UserDto userDto);
    //업데이트
    int update(UserDto userDto);
    //삭제
    int deleteById(String id);
}
